# React Chess Game

A beautiful, interactive chess game built with React, TypeScript, and Framer Motion. Play against an AI opponent with smooth animations and a modern UI.

## Features

- Play against AI opponent
- Smooth piece animations
- Valid move highlighting
- Piece capture animations
- Colorblind mode
- Sound effects
- Responsive design

## Installation

1. Clone the repository:
\`\`\`bash
git clone https://github.com/yourusername/react-chess-game.git
cd react-chess-game
\`\`\`

2. Install dependencies:
\`\`\`bash
npm install
\`\`\`

3. Start the development server:
\`\`\`bash
npm run dev
\`\`\`

4. Build for production:
\`\`\`bash
npm run build
\`\`\`

## Technologies Used

- React
- TypeScript
- Framer Motion
- Zustand
- Tailwind CSS
- Vite

## Project Structure

\`\`\`
src/
├── components/     # React components
├── store/         # Zustand store and slices
├── types/         # TypeScript types
├── utils/         # Utility functions
└── main.tsx       # Entry point
\`\`\`

## License

MIT License