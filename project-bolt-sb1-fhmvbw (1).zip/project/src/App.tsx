import React from 'react';
import { motion } from 'framer-motion';
import { AnimatedBoard } from './components/AnimatedBoard';
import { CapturedPieces } from './components/CapturedPieces';
import { GameControls } from './components/GameControls';
import { GameHeader } from './components/GameHeader';
import { useGameStore } from './store/gameStore';

function App() {
  const { moveHistory } = useGameStore();

  return (
    <motion.div
      className="min-h-screen bg-gradient-to-br from-amber-900 via-blue-900 to-amber-900 
                 flex flex-col items-center justify-center p-8 relative"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <GameControls />
      <GameHeader />

      <div className="flex gap-8 items-start">
        <CapturedPieces captures={moveHistory} color="white" />
        
        <motion.div
          className="bg-gradient-to-br from-amber-100/5 to-amber-500/5 backdrop-blur-sm p-8 rounded-2xl shadow-2xl
                     ring-1 ring-amber-500/20"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 200, damping: 20 }}
        >
          <AnimatedBoard />
        </motion.div>

        <CapturedPieces captures={moveHistory} color="black" />
      </div>

      <motion.div
        className="mt-6 text-amber-200/80 text-center max-w-md"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <p className="text-sm">Play as white against the computer. Click on a piece to see valid moves.</p>
        <p className="text-xs mt-2 text-amber-300">Use the accessibility controls in the top right for colorblind-friendly mode and sound.</p>
      </motion.div>
    </motion.div>
  );
}

export default App;