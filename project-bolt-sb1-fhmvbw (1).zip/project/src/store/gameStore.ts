import { create } from 'zustand';
import { GameState, Position } from '../types/chess';
import { createInitialBoard } from '../utils/boardUtils';
import { createBoardSlice, BoardSlice } from './slices/boardSlice';
import { createGameSlice, GameSlice } from './slices/gameSlice';

const initialState: GameState = {
  board: createInitialBoard(),
  currentPlayer: 'white',
  status: 'active',
  moveHistory: [],
  check: false,
};

export interface GameStore extends GameState, BoardSlice, GameSlice {
  initialState: GameState;
  selectedPosition: Position | null;
  validMoves: Position[];
  isThinking: boolean;
  isColorblindMode: boolean;
  isSoundEnabled: boolean;
}

export const useGameStore = create<GameStore>()((...args) => ({
  ...initialState,
  initialState,
  selectedPosition: null,
  validMoves: [],
  isThinking: false,
  isColorblindMode: false,
  isSoundEnabled: true,
  ...createBoardSlice(...args),
  ...createGameSlice(...args),
}));