import { StateCreator } from 'zustand';
import { GameStore } from '../gameStore';
import { Position } from '../../types/chess';
import { isValidMove } from '../../utils/moveValidation';
import { makeMove } from '../../utils/gameLogic';

export interface BoardSlice {
  handleSquareClick: (position: Position) => void;
  handlePieceDrop: (from: Position, to: Position) => void;
}

export const createBoardSlice: StateCreator<GameStore, [], [], BoardSlice> = (set, get) => ({
  handleSquareClick: (position) => {
    const state = get();
    const { currentPlayer, isThinking, board, selectedPosition, validMoves } = state;

    if (currentPlayer === 'black' || isThinking || state.status === 'checkmate') return;

    if (!selectedPosition) {
      const piece = board[position.row]?.[position.col];
      if (piece?.color === 'white') {
        const moves = state.getValidMoves(position, piece);
        set({ selectedPosition: position, validMoves: moves });
      }
    } else {
      const isValid = validMoves.some(move => 
        move.row === position.row && move.col === position.col
      );
      
      if (isValid) {
        state.makePlayerMove(selectedPosition, position);
      } else {
        set({ selectedPosition: null, validMoves: [] });
      }
    }
  },

  handlePieceDrop: (from, to) => {
    const state = get();
    const { currentPlayer, isThinking, validMoves } = state;

    if (currentPlayer === 'black' || isThinking) return;

    const isValid = validMoves.some(move => 
      move.row === to.row && move.col === to.col
    );

    if (isValid) {
      state.makePlayerMove(from, to);
    }
  },
});