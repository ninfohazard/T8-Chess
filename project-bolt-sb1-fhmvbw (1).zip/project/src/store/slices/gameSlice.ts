import { StateCreator } from 'zustand';
import { GameStore } from '../gameStore';
import { Position, Piece } from '../../types/chess';
import { makeMove, hasValidMoves } from '../../utils/gameLogic';
import { isValidMove } from '../../utils/moveValidation';
import { getBotMove } from '../../utils/botAI';
import { produce } from 'immer';

export interface GameSlice {
  makePlayerMove: (from: Position, to: Position) => void;
  getValidMoves: (position: Position, piece: Piece) => Position[];
  toggleColorblindMode: () => void;
  toggleSound: () => void;
  resetGame: () => void;
}

export const createGameSlice: StateCreator<GameStore, [], [], GameSlice> = (set, get) => ({
  makePlayerMove: (from, to) => {
    const state = get();
    const newGameState = makeMove(state, from, to);
    
    if (state.isSoundEnabled) {
      new Audio('/move.mp3').play().catch(() => {});
    }

    set(produce((draft) => {
      Object.assign(draft, newGameState);
      draft.selectedPosition = null;
      draft.validMoves = [];
      draft.isThinking = true;
    }));

    setTimeout(() => {
      try {
        const botMove = getBotMove(newGameState.board);
        const finalGameState = makeMove(newGameState, botMove.from, botMove.to);
        
        if (state.isSoundEnabled) {
          new Audio('/move.mp3').play().catch(() => {});
        }

        set(produce((draft) => {
          Object.assign(draft, finalGameState);
          draft.isThinking = false;

          if (!hasValidMoves(finalGameState)) {
            draft.status = draft.check ? 'checkmate' : 'stalemate';
          }
        }));
      } catch (error) {
        console.error('Bot move error:', error);
        set({ isThinking: false });
      }
    }, 1000);
  },

  getValidMoves: (position, piece) => {
    const state = get();
    const moves: Position[] = [];
    
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if (isValidMove(position, { row: r, col: c }, piece, state.board)) {
          const testState = makeMove(state, position, { row: r, col: c });
          if (!testState.check) {
            moves.push({ row: r, col: c });
          }
        }
      }
    }
    
    return moves;
  },

  toggleColorblindMode: () => set((state) => ({ 
    isColorblindMode: !state.isColorblindMode 
  })),
  
  toggleSound: () => set((state) => ({ 
    isSoundEnabled: !state.isSoundEnabled 
  })),
  
  resetGame: () => set((state) => ({ 
    ...state.initialState, 
    selectedPosition: null, 
    validMoves: [], 
    isThinking: false 
  })),
});