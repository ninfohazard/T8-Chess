import { Position, Piece, Move } from '../types/chess';
import { isValidMove } from './moveValidation';

const evaluatePiece = (piece: Piece): number => {
  const values: Record<Piece['type'], number> = {
    pawn: 1,
    knight: 3,
    bishop: 3,
    rook: 5,
    queen: 9,
    king: 0
  };
  return values[piece.type];
};

const evaluatePosition = (piece: Piece, row: number, col: number): number => {
  const centerBonus = (Math.abs(3.5 - row) + Math.abs(3.5 - col)) * -0.1;
  return centerBonus;
};

export const getBotMove = (board: (Piece | null)[][]): { from: Position; to: Position } => {
  const moves: { from: Position; to: Position; score: number }[] = [];

  // Generate all possible moves
  for (let fromRow = 0; fromRow < 8; fromRow++) {
    for (let fromCol = 0; fromCol < 8; fromCol++) {
      const piece = board[fromRow][fromCol];
      if (piece && piece.color === 'black') {
        for (let toRow = 0; toRow < 8; toRow++) {
          for (let toCol = 0; toCol < 8; toCol++) {
            const from: Position = { row: fromRow, col: fromCol };
            const to: Position = { row: toRow, col: toCol };
            
            if (isValidMove(from, to, piece, board)) {
              let score = 0;
              
              // Capture value
              const capturedPiece = board[toRow][toCol];
              if (capturedPiece) {
                score += evaluatePiece(capturedPiece) * 10;
              }
              
              // Position value
              score += evaluatePosition(piece, toRow, toCol);
              
              // Piece development
              if (fromRow === 7 || fromRow === 6) {
                score += 0.5;
              }
              
              // Center control
              if ((toRow === 3 || toRow === 4) && (toCol === 3 || toCol === 4)) {
                score += 1;
              }
              
              moves.push({ from, to, score });
            }
          }
        }
      }
    }
  }

  if (moves.length === 0) {
    throw new Error('No valid moves available');
  }

  // Add some randomness to make the bot less predictable
  moves.forEach(move => {
    move.score += Math.random() * 0.2;
  });

  // Sort moves by score and pick the best one
  moves.sort((a, b) => b.score - a.score);
  return moves[0];
};