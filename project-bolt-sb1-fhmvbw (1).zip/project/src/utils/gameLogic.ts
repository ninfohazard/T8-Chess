import { Position, Piece, PieceColor, GameState, Move } from '../types/chess';
import { isValidMove } from './moveValidation';
import { produce } from 'immer';

export const isKingInCheck = (board: (Piece | null)[][], kingColor: PieceColor): boolean => {
  let kingPos: Position | null = null;
  
  // Find king position
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece?.type === 'king' && piece.color === kingColor) {
        kingPos = { row, col };
        break;
      }
    }
    if (kingPos) break;
  }

  if (!kingPos) return false;

  // Check if any opponent piece can capture the king
  const opponentColor = kingColor === 'white' ? 'black' : 'white';
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.color === opponentColor) {
        if (isValidMove({ row, col }, kingPos, piece, board)) {
          return true;
        }
      }
    }
  }

  return false;
};

export const makeMove = (gameState: GameState, from: Position, to: Position): GameState => {
  return produce(gameState, draft => {
    const piece = draft.board[from.row][from.col];
    if (!piece) return;

    const capturedPiece = draft.board[to.row][to.col];
    const move: Move = {
      from,
      to,
      piece: { ...piece },
      capturedPiece: capturedPiece || undefined
    };

    // Handle capture animation timing
    if (capturedPiece) {
      move.capturedPiece = { ...capturedPiece };
      // The actual piece removal happens after animation in the UI
    }

    // Make the move
    draft.board[to.row][to.col] = { ...piece, hasMoved: true };
    draft.board[from.row][from.col] = null;

    // Handle pawn promotion
    if (piece.type === 'pawn' && (to.row === 0 || to.row === 7)) {
      draft.board[to.row][to.col] = { type: 'queen', color: piece.color };
      move.isPromotion = true;
    }

    // Update game state
    draft.currentPlayer = draft.currentPlayer === 'white' ? 'black' : 'white';
    draft.moveHistory.push(move);
    draft.lastMove = move;

    // Check for check
    const isInCheck = isKingInCheck(draft.board, draft.currentPlayer);
    draft.check = isInCheck;
    draft.status = isInCheck ? 'check' : 'active';

    // Check for checkmate or stalemate
    if (!hasValidMoves(draft)) {
      draft.status = isInCheck ? 'checkmate' : 'stalemate';
    }
  });
};

export const hasValidMoves = (gameState: GameState): boolean => {
  const currentColor = gameState.currentPlayer;
  
  for (let fromRow = 0; fromRow < 8; fromRow++) {
    for (let fromCol = 0; fromCol < 8; fromCol++) {
      const piece = gameState.board[fromRow][fromCol];
      if (piece?.color === currentColor) {
        for (let toRow = 0; toRow < 8; toRow++) {
          for (let toCol = 0; toCol < 8; toCol++) {
            if (isValidMove(
              { row: fromRow, col: fromCol },
              { row: toRow, col: toCol },
              piece,
              gameState.board
            )) {
              // Test if move would leave king in check
              const testState = makeMove(
                gameState,
                { row: fromRow, col: fromCol },
                { row: toRow, col: toCol }
              );
              if (!isKingInCheck(testState.board, currentColor)) {
                return true;
              }
            }
          }
        }
      }
    }
  }
  return false;
};