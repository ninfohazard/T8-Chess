import { Position, Piece } from '../types/chess';

const isPawnMove = (from: Position, to: Position, piece: Piece, board: (Piece | null)[][]): boolean => {
  const direction = piece.color === 'white' ? -1 : 1;
  const startRow = piece.color === 'white' ? 6 : 1;
  const rowDiff = to.row - from.row;
  const colDiff = Math.abs(to.col - from.col);
  
  if (colDiff === 0 && rowDiff === direction && !board[to.row][to.col]) {
    return true;
  }
  
  if (from.row === startRow && colDiff === 0 && rowDiff === 2 * direction) {
    return !board[from.row + direction][from.col] && !board[to.row][to.col];
  }
  
  if (colDiff === 1 && rowDiff === direction) {
    return board[to.row][to.col]?.color !== piece.color;
  }
  
  return false;
};

const isStraightMove = (from: Position, to: Position, board: (Piece | null)[][]): boolean => {
  const rowDiff = to.row - from.row;
  const colDiff = to.col - from.col;
  
  if (rowDiff === 0 || colDiff === 0) {
    const step = { row: Math.sign(rowDiff), col: Math.sign(colDiff) };
    let curr = { row: from.row + step.row, col: from.col + step.col };
    
    while (curr.row !== to.row || curr.col !== to.col) {
      if (board[curr.row][curr.col]) return false;
      curr.row += step.row;
      curr.col += step.col;
    }
    return true;
  }
  return false;
};

const isDiagonalMove = (from: Position, to: Position, board: (Piece | null)[][]): boolean => {
  const rowDiff = to.row - from.row;
  const colDiff = to.col - from.col;
  
  if (Math.abs(rowDiff) === Math.abs(colDiff)) {
    const step = { row: Math.sign(rowDiff), col: Math.sign(colDiff) };
    let curr = { row: from.row + step.row, col: from.col + step.col };
    
    while (curr.row !== to.row && curr.col !== to.col) {
      if (board[curr.row][curr.col]) return false;
      curr.row += step.row;
      curr.col += step.col;
    }
    return true;
  }
  return false;
};

export const isValidMove = (from: Position, to: Position, piece: Piece, board: (Piece | null)[][]): boolean => {
  if (!piece || board[to.row][to.col]?.color === piece.color) return false;

  const moveValidators: Record<Piece['type'], () => boolean> = {
    pawn: () => isPawnMove(from, to, piece, board),
    rook: () => isStraightMove(from, to, board),
    bishop: () => isDiagonalMove(from, to, board),
    queen: () => isStraightMove(from, to, board) || isDiagonalMove(from, to, board),
    king: () => Math.abs(to.row - from.row) <= 1 && Math.abs(to.col - from.col) <= 1,
    knight: () => {
      const rowDiff = Math.abs(to.row - from.row);
      const colDiff = Math.abs(to.col - from.col);
      return (rowDiff === 2 && colDiff === 1) || (rowDiff === 1 && colDiff === 2);
    }
  };

  return moveValidators[piece.type]();
};