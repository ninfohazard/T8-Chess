import React from 'react';
import { Piece } from '../types/chess';
import {
  Circle,
  Sword,
  Cross,
  Crown,
  Castle,
  Shield
} from 'lucide-react';

interface PieceComponentProps {
  piece: Piece;
}

export const PieceComponent: React.FC<PieceComponentProps> = ({ piece }) => {
  const color = piece.color === 'white' ? '#ffffff' : '#000000';
  const strokeColor = piece.color === 'white' ? '#000000' : '#ffffff';
  const size = 40;

  const getPieceIcon = () => {
    switch (piece.type) {
      case 'pawn':
        return <Circle size={size} fill={color} stroke={strokeColor} />;
      case 'knight':
        return <Sword size={size} fill={color} stroke={strokeColor} />;
      case 'bishop':
        return <Cross size={size} fill={color} stroke={strokeColor} />;
      case 'rook':
        return <Castle size={size} fill={color} stroke={strokeColor} />;
      case 'queen':
        return <Crown size={size} fill={color} stroke={strokeColor} />;
      case 'king':
        return <Shield size={size} fill={color} stroke={strokeColor} />;
    }
  };

  return (
    <div className="cursor-pointer">
      {getPieceIcon()}
    </div>
  );
};