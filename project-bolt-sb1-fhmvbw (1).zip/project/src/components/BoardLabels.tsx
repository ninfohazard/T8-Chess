import React from 'react';

export const BoardLabels: React.FC = () => {
  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  const ranks = ['8', '7', '6', '5', '4', '3', '2', '1'];

  return (
    <>
      {/* File labels (a-h) */}
      <div className="absolute -bottom-6 left-0 right-0 flex justify-around px-2">
        {files.map(file => (
          <span key={file} className="text-amber-200/80 text-sm font-medium">
            {file}
          </span>
        ))}
      </div>
      
      {/* Rank labels (1-8) */}
      <div className="absolute -left-6 top-0 bottom-0 flex flex-col justify-around py-1">
        {ranks.map(rank => (
          <span key={rank} className="text-amber-200/80 text-sm font-medium">
            {rank}
          </span>
        ))}
      </div>
    </>
  );
};