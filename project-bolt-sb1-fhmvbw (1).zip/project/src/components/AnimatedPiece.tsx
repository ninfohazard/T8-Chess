import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Piece as PieceType } from '../types/chess';
import { Crown, Castle, Cross, Shield, Sword, Circle } from 'lucide-react';

interface AnimatedPieceProps {
  piece: PieceType;
  isSelected?: boolean;
  isBeingCaptured?: boolean;
  onCapture?: () => void;
}

export const AnimatedPiece: React.FC<AnimatedPieceProps> = ({
  piece,
  isSelected,
  isBeingCaptured,
  onCapture
}) => {
  const baseStyle = piece.color === 'white'
    ? 'text-amber-50 filter drop-shadow-lg'
    : 'text-gray-900 filter brightness-95';

  const iconProps = {
    size: 36,
    strokeWidth: piece.color === 'white' ? 1.5 : 2,
    className: `
      ${baseStyle}
      transition-all duration-200
      ${piece.color === 'white'
        ? 'fill-amber-50 stroke-amber-200'
        : 'fill-gray-900 stroke-amber-900'}
    `
  };

  const getPieceIcon = () => {
    switch (piece.type) {
      case 'king': return <Crown {...iconProps} />;
      case 'queen': return <Shield {...iconProps} />;
      case 'bishop': return <Cross {...iconProps} />;
      case 'knight': return <Sword {...iconProps} />;
      case 'rook': return <Castle {...iconProps} />;
      case 'pawn': return <Circle {...iconProps} />;
      default: return null;
    }
  };

  return (
    <AnimatePresence onExitComplete={onCapture}>
      <motion.div
        className="piece-wrapper absolute"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{
          scale: isSelected ? 1.1 : 1,
          opacity: isBeingCaptured ? 0 : 1,
          x: isBeingCaptured ? (piece.color === 'white' ? -100 : 100) : 0,
          y: isBeingCaptured ? (piece.color === 'white' ? 100 : -100) : 0,
          rotate: isBeingCaptured ? (piece.color === 'white' ? -45 : 45) : 0
        }}
        exit={{ 
          scale: 0.8, 
          opacity: 0,
          x: piece.color === 'white' ? -100 : 100,
          y: piece.color === 'white' ? 100 : -100,
          rotate: piece.color === 'white' ? -45 : 45
        }}
        whileHover={{ scale: 1.1 }}
        transition={{
          type: "spring",
          stiffness: 300,
          damping: 15
        }}
      >
        {getPieceIcon()}
      </motion.div>
    </AnimatePresence>
  );
};