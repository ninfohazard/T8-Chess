import React from 'react';
import { Move } from '../types/chess';

interface MoveHistoryProps {
  moves: Move[];
}

export const MoveHistory: React.FC<MoveHistoryProps> = ({ moves }) => {
  const getMoveNotation = (move: Move): string => {
    const files = 'abcdefgh';
    const ranks = '87654321';
    const from = `${files[move.from.col]}${ranks[move.from.row]}`;
    const to = `${files[move.to.col]}${ranks[move.to.row]}`;
    
    let notation = move.piece.type === 'pawn' ? '' : move.piece.type.toUpperCase();
    
    if (move.capturedPiece) {
      if (move.piece.type === 'pawn') notation = from[0];
      notation += 'x';
    }
    
    notation += to;
    
    if (move.isPromotion) notation += '=Q';
    if (move.isCastling) {
      notation = move.to.col > move.from.col ? 'O-O' : 'O-O-O';
    }
    
    return notation;
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-md p-4 max-h-[200px] overflow-y-auto custom-scrollbar">
      <h2 className="text-sm font-bold text-amber-900 mb-2">Move History</h2>
      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
        {Array.from({ length: Math.ceil(moves.length / 2) }).map((_, index) => (
          <React.Fragment key={index}>
            <div className="font-mono text-amber-900">
              {moves[index * 2] ? getMoveNotation(moves[index * 2]) : ''}
            </div>
            <div className="font-mono text-amber-700">
              {moves[index * 2 + 1] ? getMoveNotation(moves[index * 2 + 1]) : ''}
            </div>
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};