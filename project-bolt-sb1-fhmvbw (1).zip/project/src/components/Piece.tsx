import React from 'react';
import { motion } from 'framer-motion';
import { Piece as PieceType } from '../types/chess';
import { Crown, Castle, Cross, Shield, Sword, Circle } from 'lucide-react';
import { useGameStore } from '../store/gameStore';

interface PieceProps {
  piece: PieceType;
  isSelected?: boolean;
}

export const PieceComponent: React.FC<PieceProps> = ({ piece, isSelected }) => {
  const isColorblindMode = useGameStore((state) => state.isColorblindMode);

  const baseStyle = piece.color === 'white'
    ? 'text-amber-50 filter drop-shadow-lg'
    : 'text-gray-900 filter brightness-95';

  const colorblindPattern = isColorblindMode
    ? piece.color === 'white'
      ? 'bg-dots-pattern'
      : 'bg-stripes-pattern'
    : '';

  const glowEffect = isSelected
    ? 'animate-glow ring-4 ring-amber-400 ring-opacity-50'
    : '';

  const iconProps = {
    size: 36,
    strokeWidth: piece.color === 'white' ? 1.5 : 2,
    className: `
      ${baseStyle}
      ${colorblindPattern}
      ${glowEffect}
      transition-all duration-200
      ${piece.color === 'white'
        ? 'fill-amber-50 stroke-amber-200'
        : 'fill-gray-900 stroke-amber-900'}
    `
  };

  return (
    <motion.div
      className="piece-wrapper"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 15 }}
    >
      {(() => {
        switch (piece.type) {
          case 'king': return <Crown {...iconProps} />;
          case 'queen': return <Shield {...iconProps} />;
          case 'bishop': return <Cross {...iconProps} />;
          case 'knight': return <Sword {...iconProps} />;
          case 'rook': return <Castle {...iconProps} />;
          case 'pawn': return <Circle {...iconProps} />;
          default: return null;
        }
      })()}
    </motion.div>
  );
};