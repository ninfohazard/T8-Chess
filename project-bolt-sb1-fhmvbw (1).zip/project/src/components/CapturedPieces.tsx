import React from 'react';
import { motion } from 'framer-motion';
import { Move } from '../types/chess';
import { AnimatedPiece } from './AnimatedPiece';

interface CapturedPiecesProps {
  captures: Move[];
  color: 'white' | 'black';
}

export const CapturedPieces: React.FC<CapturedPiecesProps> = ({ captures = [], color }) => {
  const capturedPieces = captures
    .filter(move => move?.capturedPiece?.color === color)
    .map(move => move.capturedPiece!)
    .filter(Boolean);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { 
      opacity: 0,
      x: color === 'white' ? -20 : 20,
      y: color === 'white' ? 20 : -20
    },
    show: { 
      opacity: 1,
      x: 0,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    }
  };

  return (
    <motion.div
      className="flex flex-wrap gap-2 p-4 bg-white/10 backdrop-blur-sm rounded-xl min-w-[120px] min-h-[200px]"
      variants={container}
      initial="hidden"
      animate="show"
    >
      <h3 className="w-full text-sm font-medium text-amber-200 mb-2">
        Captured {color} pieces
      </h3>
      {capturedPieces.map((piece, index) => (
        <motion.div
          key={`${piece.type}-${index}`}
          variants={item}
          className="relative"
        >
          <AnimatedPiece piece={piece} />
        </motion.div>
      ))}
    </motion.div>
  );
};