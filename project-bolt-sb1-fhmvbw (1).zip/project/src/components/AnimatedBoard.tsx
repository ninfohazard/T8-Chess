import React from 'react';
import { motion } from 'framer-motion';
import { AnimatedSquare } from './AnimatedSquare';
import { BoardLabels } from './BoardLabels';
import { Position } from '../types/chess';
import { useGameStore } from '../store/gameStore';

export const AnimatedBoard: React.FC = () => {
  const {
    board,
    selectedPosition,
    validMoves,
    handleSquareClick
  } = useGameStore();

  const getSquareColor = (row: number, col: number): 'light' | 'dark' => {
    return (row + col) % 2 === 0 ? 'light' : 'dark';
  };

  if (!board) return null;

  return (
    <div className="relative">
      <motion.div
        className="chess-board grid grid-cols-8 gap-0.5 p-2 bg-gradient-to-br from-amber-700 to-amber-900 rounded-xl shadow-2xl"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        {board.map((row, rowIndex) => (
          row.map((piece, colIndex) => {
            const position = { row: rowIndex, col: colIndex };
            const isSelected = selectedPosition?.row === rowIndex && 
                             selectedPosition?.col === colIndex;
            const isValidMove = validMoves.some(move => 
              move.row === rowIndex && move.col === colIndex
            );
            const hasCapturablePiece = isValidMove && board[rowIndex][colIndex]?.color !== piece?.color;

            return (
              <AnimatedSquare
                key={`${rowIndex}-${colIndex}`}
                piece={piece}
                position={position}
                isSelected={isSelected}
                isValidMove={isValidMove}
                isCapturablePiece={hasCapturablePiece}
                color={getSquareColor(rowIndex, colIndex)}
                onSquareClick={handleSquareClick}
              />
            );
          })
        ))}
      </motion.div>
      <BoardLabels />
    </div>
  );
};