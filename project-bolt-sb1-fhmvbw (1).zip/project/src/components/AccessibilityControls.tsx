import React from 'react';
import { motion } from 'framer-motion';
import { Eye } from 'lucide-react';
import { useGameStore } from '../store/gameStore';

export const AccessibilityControls: React.FC = () => {
  const { isColorblindMode, toggleColorblindMode } = useGameStore();

  return (
    <motion.div
      className="absolute top-4 right-4"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
    >
      <button
        onClick={toggleColorblindMode}
        className={`
          p-2 rounded-full transition-colors duration-200
          ${isColorblindMode ? 'bg-amber-400 text-white' : 'bg-white/10 text-amber-200'}
          hover:bg-amber-500 hover:text-white
        `}
        aria-label="Toggle colorblind mode"
      >
        <Eye size={24} />
      </button>
    </motion.div>
  );
};