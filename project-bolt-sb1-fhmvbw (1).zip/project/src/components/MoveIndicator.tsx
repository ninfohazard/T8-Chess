import React from 'react';
import { motion } from 'framer-motion';

interface MoveIndicatorProps {
  isCapture?: boolean;
}

export const MoveIndicator: React.FC<MoveIndicatorProps> = ({ isCapture }) => {
  return (
    <motion.div
      className={`absolute ${
        isCapture 
          ? 'w-full h-full border-2 border-amber-400/40 rounded-lg' 
          : 'w-3 h-3 rounded-full bg-amber-400/40'
      }`}
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ 
        scale: [1, 1.1, 1],
        opacity: [0.4, 0.6, 0.4]
      }}
      transition={{
        repeat: Infinity,
        duration: 2,
        ease: "easeInOut"
      }}
    />
  );
};