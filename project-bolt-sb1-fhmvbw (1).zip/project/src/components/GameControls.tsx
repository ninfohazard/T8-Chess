import React from 'react';
import { motion } from 'framer-motion';
import { RotateCcw, Volume2, VolumeX, Eye } from 'lucide-react';
import { useGameStore } from '../store/gameStore';

export const GameControls: React.FC = () => {
  const { resetGame, toggleColorblindMode, isColorblindMode, toggleSound, isSoundEnabled } = useGameStore();

  return (
    <motion.div
      className="absolute top-4 right-4 flex gap-2"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
    >
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => toggleSound()}
        className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-amber-200 transition-colors"
        aria-label={isSoundEnabled ? "Mute sound" : "Enable sound"}
      >
        {isSoundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
      </motion.button>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={toggleColorblindMode}
        className={`p-2 rounded-full transition-colors ${
          isColorblindMode ? 'bg-amber-400 text-white' : 'bg-white/10 text-amber-200'
        } hover:bg-amber-500`}
        aria-label="Toggle colorblind mode"
      >
        <Eye size={20} />
      </motion.button>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={resetGame}
        className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-amber-200 transition-colors"
        aria-label="Reset game"
      >
        <RotateCcw size={20} />
      </motion.button>
    </motion.div>
  );
};