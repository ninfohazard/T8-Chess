import React from 'react';
import { motion } from 'framer-motion';
import { Piece, Position } from '../types/chess';
import { PieceComponent } from './Piece';
import { useGameStore } from '../store/gameStore';

interface SquareProps {
  piece: Piece | null;
  isSelected: boolean;
  isValidMove: boolean;
  color: 'light' | 'dark';
  position: Position;
}

export const Square: React.FC<SquareProps> = ({
  piece,
  isSelected,
  isValidMove,
  color,
  position,
}) => {
  const { handleSquareClick, isColorblindMode } = useGameStore();

  const baseClasses = "w-16 h-16 flex items-center justify-center relative transition-all duration-300";
  
  const colorClasses = color === 'light'
    ? `bg-gradient-to-br from-amber-50 to-amber-100 ${isColorblindMode ? 'bg-dots-pattern' : ''}`
    : `bg-gradient-to-br from-amber-800 to-amber-900 ${isColorblindMode ? 'bg-stripes-pattern' : ''}`;

  const marbleTexture = color === 'light'
    ? 'after:absolute after:inset-0 after:bg-marble-light after:opacity-10'
    : 'after:absolute after:inset-0 after:bg-marble-dark after:opacity-10';

  const hoverEffect = piece || isValidMove
    ? 'hover:ring-2 hover:ring-amber-400/50 hover:scale-[1.02]'
    : '';

  return (
    <motion.div
      className={`
        ${baseClasses}
        ${colorClasses}
        ${marbleTexture}
        ${isSelected ? 'ring-4 ring-amber-400 ring-opacity-50 z-10' : ''}
        ${hoverEffect}
        cursor-pointer
        shadow-inner
      `}
      onClick={() => handleSquareClick(position)}
      whileHover={{ scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      {piece && <PieceComponent piece={piece} isSelected={isSelected} />}
      {isValidMove && (
        <motion.div
          className="absolute w-4 h-4 rounded-full bg-amber-400 opacity-40"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.4, 0.6, 0.4]
          }}
          transition={{
            repeat: Infinity,
            duration: 2,
            ease: "easeInOut"
          }}
        />
      )}
    </motion.div>
  );
};