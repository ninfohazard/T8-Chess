import React from 'react';
import { motion } from 'framer-motion';
import { Position, Piece } from '../types/chess';
import { DraggablePiece } from './DraggablePiece';
import { MoveIndicator } from './MoveIndicator';
import { useGameStore } from '../store/gameStore';

interface AnimatedSquareProps {
  piece: Piece | null;
  position: Position;
  isSelected: boolean;
  isValidMove: boolean;
  isCapturablePiece: boolean;
  color: 'light' | 'dark';
  onSquareClick: (position: Position) => void;
}

export const AnimatedSquare: React.FC<AnimatedSquareProps> = ({
  piece,
  position,
  isSelected,
  isValidMove,
  isCapturablePiece,
  color,
  onSquareClick,
}) => {
  const { handlePieceDrop } = useGameStore();
  const squareSize = 64; // 4rem (w-16)

  const baseClasses = "w-16 h-16 flex items-center justify-center relative transition-all duration-300";
  
  const colorClasses = color === 'light'
    ? 'bg-gradient-to-br from-amber-50 to-amber-100'
    : 'bg-gradient-to-br from-amber-800 to-amber-900';

  const marbleTexture = color === 'light'
    ? 'after:absolute after:inset-0 after:bg-marble-light after:opacity-10'
    : 'after:absolute after:inset-0 after:bg-marble-dark after:opacity-10';

  return (
    <motion.div
      className={`
        ${baseClasses}
        ${colorClasses}
        ${marbleTexture}
        ${isSelected ? 'ring-4 ring-amber-400 ring-opacity-50 z-10' : ''}
        cursor-pointer
        shadow-inner
      `}
      onClick={() => onSquareClick(position)}
      whileHover={{ scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      {piece && (
        <DraggablePiece
          piece={piece}
          position={position}
          squareSize={squareSize}
          isSelected={isSelected}
          onDragStart={() => onSquareClick(position)}
          onDragEnd={(newPosition) => handlePieceDrop(position, newPosition)}
        />
      )}
      {isValidMove && (
        <MoveIndicator isCapture={isCapturablePiece} />
      )}
    </motion.div>
  );
};