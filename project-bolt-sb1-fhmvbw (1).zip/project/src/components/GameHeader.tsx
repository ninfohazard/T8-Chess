import React from 'react';
import { motion } from 'framer-motion';
import { Crown } from 'lucide-react';
import { useGameStore } from '../store/gameStore';

export const GameHeader: React.FC = () => {
  const { status, currentPlayer, isThinking } = useGameStore();

  return (
    <motion.div
      className="text-center mb-8"
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-center justify-center gap-3 mb-2">
        <Crown className="w-8 h-8 text-amber-300" />
        <h1 className="text-5xl font-bold text-amber-200 font-serif">Chess Master</h1>
        <Crown className="w-8 h-8 text-amber-300" />
      </div>
      
      <motion.div
        className="flex items-center justify-center gap-2 text-amber-100/80"
        animate={{ opacity: isThinking ? 0.6 : 1 }}
      >
        <div className={`w-3 h-3 rounded-full ${currentPlayer === 'white' ? 'bg-white' : 'bg-gray-800'}`} />
        <span className="text-lg">
          {status === 'check' ? 'Check!' : `${currentPlayer === 'white' ? 'Your' : "Bot's"} turn`}
        </span>
        {isThinking && (
          <div className="flex gap-1 ml-2">
            <motion.div
              className="w-2 h-2 bg-amber-300 rounded-full"
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
            />
            <motion.div
              className="w-2 h-2 bg-amber-300 rounded-full"
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
            />
            <motion.div
              className="w-2 h-2 bg-amber-300 rounded-full"
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
            />
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};