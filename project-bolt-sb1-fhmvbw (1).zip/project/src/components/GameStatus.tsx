import React from 'react';
import { PieceColor, GameStatus as GameStatusType } from '../types/chess';

interface GameStatusProps {
  currentPlayer: PieceColor;
  isThinking: boolean;
  status: GameStatusType;
}

export const GameStatus: React.FC<GameStatusProps> = ({ 
  currentPlayer, 
  isThinking,
  status 
}) => {
  const getStatusMessage = () => {
    if (status === 'check') return 'Check!';
    if (status === 'checkmate') return `Checkmate! ${currentPlayer === 'white' ? 'Black' : 'White'} wins!`;
    if (status === 'stalemate') return 'Stalemate! Game is drawn.';
    return isThinking ? 'Bot is thinking...' : `${currentPlayer === 'white' ? 'Your' : "Bot's"} turn`;
  };

  return (
    <div className="mt-6 text-lg font-medium">
      <div className="flex items-center justify-center gap-3 bg-white/60 backdrop-blur-sm rounded-lg p-3 shadow-md">
        <div className={`w-4 h-4 rounded-full ${currentPlayer === 'white' ? 'bg-white border-2 border-gray-400' : 'bg-gray-800'} shadow-inner`} />
        <span className={`${status === 'check' ? 'text-red-600 font-bold' : 'text-gray-700'} transition-colors duration-200`}>
          {getStatusMessage()}
        </span>
        {isThinking && (
          <div className="flex gap-1">
            <div className="w-2 h-2 bg-amber-600 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
            <div className="w-2 h-2 bg-amber-600 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
            <div className="w-2 h-2 bg-amber-600 rounded-full animate-bounce"></div>
          </div>
        )}
      </div>
    </div>
  );
};