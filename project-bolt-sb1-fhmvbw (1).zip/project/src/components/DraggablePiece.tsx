import React from 'react';
import { motion, useAnimation, PanInfo } from 'framer-motion';
import { Position, Piece as PieceType } from '../types/chess';
import { Crown, Castle, Cross, Shield, Sword, Circle } from 'lucide-react';
import { useGameStore } from '../store/gameStore';

interface DraggablePieceProps {
  piece: PieceType;
  position: Position;
  squareSize: number;
  isSelected?: boolean;
  onDragStart?: () => void;
  onDragEnd?: (position: Position) => void;
}

export const DraggablePiece: React.FC<DraggablePieceProps> = ({
  piece,
  position,
  squareSize,
  isSelected,
  onDragStart,
  onDragEnd,
}) => {
  const controls = useAnimation();
  const { validMoves, currentPlayer, isThinking } = useGameStore();

  const baseStyle = piece.color === 'white'
    ? 'text-amber-50 filter drop-shadow-lg'
    : 'text-gray-900 filter brightness-95';

  const iconProps = {
    size: squareSize * 0.75,
    strokeWidth: piece.color === 'white' ? 1.5 : 2,
    className: `
      ${baseStyle}
      transition-all duration-200
      ${piece.color === 'white'
        ? 'fill-amber-50 stroke-amber-200'
        : 'fill-gray-900 stroke-amber-900'}
    `
  };

  const getPieceIcon = () => {
    switch (piece.type) {
      case 'king': return <Crown {...iconProps} />;
      case 'queen': return <Shield {...iconProps} />;
      case 'bishop': return <Cross {...iconProps} />;
      case 'knight': return <Sword {...iconProps} />;
      case 'rook': return <Castle {...iconProps} />;
      case 'pawn': return <Circle {...iconProps} />;
      default: return null;
    }
  };

  const handleDragStart = () => {
    if (piece.color !== currentPlayer || isThinking) return false;
    onDragStart?.();
  };

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const boardRect = document.querySelector('.chess-board')?.getBoundingClientRect();
    if (!boardRect) return;

    const newPosition: Position = {
      row: Math.floor((info.point.y - boardRect.top) / squareSize),
      col: Math.floor((info.point.x - boardRect.left) / squareSize),
    };

    // Check if the new position is within the board bounds
    if (
      newPosition.row >= 0 && newPosition.row < 8 &&
      newPosition.col >= 0 && newPosition.col < 8
    ) {
      const isValidMove = validMoves.some(
        move => move.row === newPosition.row && move.col === newPosition.col
      );

      if (isValidMove) {
        onDragEnd?.(newPosition);
      } else {
        // Animate piece back to original position
        controls.start({ x: 0, y: 0 });
      }
    } else {
      // Animate piece back to original position if dropped outside the board
      controls.start({ x: 0, y: 0 });
    }
  };

  return (
    <motion.div
      className="piece-wrapper absolute cursor-grab active:cursor-grabbing"
      animate={controls}
      drag
      dragConstraints={{
        left: -position.col * squareSize,
        right: (7 - position.col) * squareSize,
        top: -position.row * squareSize,
        bottom: (7 - position.row) * squareSize,
      }}
      dragElastic={0.2}
      dragMomentum={false}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      whileDrag={{ scale: 1.1, zIndex: 100 }}
      style={{
        width: squareSize,
        height: squareSize,
        zIndex: isSelected ? 20 : 10,
      }}
    >
      <motion.div
        className="flex items-center justify-center w-full h-full"
        animate={{
          scale: isSelected ? 1.1 : 1,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 15 }}
      >
        {getPieceIcon()}
      </motion.div>
    </motion.div>
  );
};